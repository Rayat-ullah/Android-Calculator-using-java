package com.example.newcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    EditText et1,et2;
    Button add, sub, mul, div;
    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = findViewById(R.id.et1);//here is class which is already define in android and hold the id of all the views.
        et2 = findViewById(R.id.et2);
        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        mul = findViewById(R.id.mul);
        div = findViewById(R.id.div);
        tv1 = findViewById(R.id.tv1);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a, b, c;
                a = Integer.parseInt(et1.getText().toString());//string to integer.
                b = Integer.parseInt(et2.getText().toString());
                c = a + b;
                tv1.setText("Result is :" +c);
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a, b, c;
                a = Integer.parseInt(et1.getText().toString());//string to integer.
                b = Integer.parseInt(et2.getText().toString());
                c = a - b;
                tv1.setText("Result is :" +c);
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a, b, c;
                a = Integer.parseInt(et1.getText().toString());//string to integer.
                b = Integer.parseInt(et2.getText().toString());
                c = a * b;
                tv1.setText("Result is :" +c);
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a, b, c;
                a = Integer.parseInt(et1.getText().toString());//string to integer.
                b = Integer.parseInt(et2.getText().toString());
                c = a / b;
                tv1.setText("Result is : " +c);

            }
        });
    }}



